package com.bfhl;

import com.bfhl.service.WebhookService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import javax.annotation.PostConstruct;

@SpringBootApplication
public class BfhlApplication {

    private final WebhookService webhookService;

    public BfhlApplication(WebhookService webhookService) {
        this.webhookService = webhookService;
    }

    public static void main(String[] args) {
        SpringApplication.run(BfhlApplication.class, args);
    }

    @PostConstruct
    public void runOnStartup() {
        webhookService.executeWorkflow();
    }
}
