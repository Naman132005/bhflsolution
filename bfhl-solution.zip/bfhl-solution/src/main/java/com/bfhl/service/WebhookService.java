package com.bfhl.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

@Service
public class WebhookService {

    private final RestTemplate restTemplate = new RestTemplate();

    public void executeWorkflow() {
        String webhookGenUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        Map<String, Object> body = new HashMap<>();
        body.put("name", "Naman Namdev");
        body.put("regNo", "8718016541");
        body.put("email", "namannamdev220314@acropolis.in");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        ResponseEntity<Map> response = restTemplate.exchange(webhookGenUrl, HttpMethod.POST, entity, Map.class);
        String webhookUrl = response.getBody().get("webhook").toString();
        String token = response.getBody().get("accessToken").toString();

        String finalQuery = "SELECT p.amount AS SALARY, CONCAT(e.first_name, ' ', e.last_name) AS NAME, " +
                "FLOOR(DATEDIFF(CURDATE(), e.dob) / 365.25) AS AGE, d.department_name AS DEPARTMENT_NAME " +
                "FROM payments p JOIN employee e ON p.emp_id = e.emp_id JOIN department d ON e.department = d.department_id " +
                "WHERE DAY(p.payment_time) != 1 ORDER BY p.amount DESC LIMIT 1;";

        Map<String, String> answerBody = new HashMap<>();
        answerBody.put("finalQuery", finalQuery);

        HttpHeaders answerHeaders = new HttpHeaders();
        answerHeaders.setContentType(MediaType.APPLICATION_JSON);
        answerHeaders.setBearerAuth(token);
        HttpEntity<Map<String, String>> answerEntity = new HttpEntity<>(answerBody, answerHeaders);

        ResponseEntity<String> answerResponse = restTemplate.postForEntity(webhookUrl, answerEntity, String.class);
        System.out.println("Submission Response: " + answerResponse.getBody());
    }
}
